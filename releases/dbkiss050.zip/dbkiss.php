<?php

// dbkiss v0.5 (2008-04-11)
// Author: Cezary Tomczak [code.gosu.pl / cagret at gmail com]
// License: BSD (revised)

function rget($name)
{
    return rvar($name, 'get');
}
function rpost($name)
{
    return rvar($name, 'post');
}
function rvar($name, $method)
{
    if (is_array($name)) {
        $ret = array();
        foreach ($name as $k => $v) {
            if (!is_numeric($k)) {
                if ($v == 'str') $ret[$k] = (string) rvar($k, $method);
                else if ($v == 'str_null') {
                    $str_val = rvar($k, $method);
                    if (strlen($str_val)) {
                        $ret[$k] = (string) $str_val;
                    } else {
                        $ret[$k] = null;
                    }
                }
                else if ($v == 'int') $ret[$k] = (int) rvar($k, $method);
                else if ($v == 'int_null') {
                    $int_val = rvar($k, $method);
                    if (strlen($int_val)) {
                        $ret[$k] = (int) $int_val;
                    } else {
                        $ret[$k] = null;
                    }
                }
                else if ($v == 'float') {
                    $float_val = trim(rvar($k, $method));
                    $float_val = str_replace(',', '.', $float_val);
                    $ret[$k] = (float) $float_val;
                }
                else if ($v == 'float_null') {
                    $float_val = trim(rvar($k, $method));
                    $float_val = str_replace(',', '.', $float_val);
                    $ret[$k] = (float) $float_val;
                    if (!$ret[$k]) $ret[$k] = null;
                }
                else if ($v == 'bool') $ret[$k] = (bool) rvar($k, $method);
                else if ($v == 'arr') $ret[$k] = (array) rvar($k, $method);
                else trigger_error('rvar() failed, unknown var type: '.$v, E_USER_ERROR);
            } else {
                $ret[$v] = rvar($v, $method);
            }
        }
        return $ret;
    }
    if (function_exists('listing_ofs')) {
        if (str_starts_with($name, 'ofs')) {
            listing_ofs($name);
        }
    }
    $method = strtolower($method);
    if ('get' == $method) {
        if (isset($_GET[$name])) {
            return $_GET[$name];
        }
    }
    else if ('post' == $method) {
        if (isset($_POST[$name])) {
            return $_POST[$name];
        }
    }
    else {
        trigger_error('rvar() failed, unknown method: '.$method, E_USER_ERROR);
    }    
    return null;
}

ini_set('magic_quotes_runtime', 0);
if (ini_get('magic_quotes_gpc')) {
    strip_quotes($_GET);
    strip_quotes($_POST);
    strip_quotes($_REQUEST);
    strip_quotes($_COOKIE);
}
function strip_quotes(&$gpc)
{
    if (is_array($gpc)) {
        foreach ($gpc as $k => $v) { strip_quotes($gpc[$k]); }
    } else {
        $gpc = stripslashes($gpc);
    }
}

global $db_link, $db_name;

define('COOKIE_WEEK', 604800); // 3600*24*7
define('COOKIE_SESS', 0);
function cookie_get($key)
{
    if (isset($_COOKIE[$key])) return $_COOKIE[$key];
    return null;
}
function cookie_set($key, $val, $time = COOKIE_SESS)
{
    $expire = $time ? time() + $time : 0;
    setcookie($key, $val, $expire);
    $_COOKIE[$key] = $val;
}
function cookie_del($key)
{
    setcookie($key, '', time()-3600*24);
    unset($_COOKIE[$key]);
}

conn_modify('db_name');
conn_modify('db_charset');
conn_modify('page_charset');

function conn_modify($key)
{
    if (array_key_exists($key, $_GET)) {
        cookie_set($key, $_GET[$key], cookie_get('remember') ? COOKIE_WEEK : COOKIE_SESS);
        if (@$_GET['from']) {
            header('Location: '.$_GET['from']);
        } else {
            header('Location: '.$_SERVER['PHP_SELF']);
        }
        exit;
    }
}

$db_driver = cookie_get('db_driver');
$db_server = cookie_get('db_server');
$db_name = cookie_get('db_name');
$db_user = cookie_get('db_user');
$db_pass = base64_decode(cookie_get('db_pass'));
$db_charset = cookie_get('db_charset');
$page_charset = cookie_get('page_charset');

$charset1 = array('latin1', 'latin2', 'utf-8', 'cp1250');
$charset2 = array('iso-8859-1', 'iso-8859-2', 'utf-8', 'windows-1250');
$charset1[] = $db_charset;
$charset2[] = $page_charset;
$charset1 = charset_assoc($charset1);
$charset2 = charset_assoc($charset2);

$driver_arr = array('mysql', 'pgsql');
$driver_arr = array_assoc($driver_arr);

function array_assoc($a)
{
    $ret = array();
    foreach ($a as $v) {
        $ret[$v] = $v;
    }
    return $ret;
}
function charset_assoc($arr)
{
    sort($arr);
    $ret = array();
    foreach ($arr as $v) {
        if (!$v) { continue; }
        $v = strtolower($v);
        $ret[$v] = $v;
    }
    return $ret;
}


if (@$_GET['disconnect'])
{
    cookie_del('db_pass');
    header('Location: '.$_SERVER['PHP_SELF']);
    exit;
}

if (!$db_pass || (!$db_driver || !$db_server || !$db_name || !$db_user))
{
    if ('POST' == $_SERVER['REQUEST_METHOD'])
    {
        $db_driver = rpost('db_driver');
        $db_server = @$_POST['db_server'];
        $db_name = @$_POST['db_name'];
        $db_user = @$_POST['db_user'];
        $db_pass = @$_POST['db_pass'];
        $db_charset = @$_POST['db_charset'];
        $page_charset = @$_POST['page_charset'];
        
        if ($db_driver && $db_server && $db_name && $db_user)
        {
            $db_test = true;
            db_connect($db_server, $db_name, $db_user, $db_pass);
            if (is_resource($db_link))
            {
                $time = @$_POST['remember'] ? COOKIE_WEEK : COOKIE_SESS;
                cookie_set('db_driver', $db_driver, $time);
                cookie_set('db_server', $db_server, $time);
                cookie_set('db_name', $db_name, $time);
                cookie_set('db_user', $db_user, $time);
                cookie_set('db_pass', base64_encode($db_pass), $time);
                cookie_set('db_charset', $db_charset, $time);
                cookie_set('page_charset', $page_charset, $time);
                cookie_set('remember', @$_POST['remember'], $time);
                header('Location: '.$_SERVER['PHP_SELF']);
                exit;
            }
        }
    }
    else
    {
        $_POST['db_driver'] = $db_driver;
        $_POST['db_server'] = $db_server ? $db_server : 'localhost';
        $_POST['db_name'] = $db_name;
        $_POST['db_user'] = $db_user;
        $_POST['db_charset'] = $db_charset;
        $_POST['page_charset'] = $page_charset;
        $_POST['db_driver'] = $db_driver;
    }
    ?>

        <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
        <html>
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
            <title>Connect</title>
        </head>
        <body>

        <?php layout(); ?>

        <h1>Connect</h1>

        <? if (isset($db_test) && is_string($db_test)): ?>
            <div style="background: #ffffd7; padding: 0.5em; border: #ccc 1px solid; margin-bottom: 1em;">
                <span style="color: red; font-weight: bold;">Error:</span>&nbsp;
                <?=$db_test;?>
            </div>
        <? endif; ?>

        <form action="<?=$_SERVER['PHP_SELF'];?>" method="post">
        <table cellspacing="1">
        <tr>
            <th>Driver:</th>
            <td><select name="db_driver"><?=options($driver_arr, rpost('db_driver'));?></select></td>
        </tr>
        <tr>
            <th>Server:</th>
            <td><input type="text" name="db_server" value="<?=rpost('db_server');?>"></td>
        </tr>
        <tr>
            <th>Database:</th>
            <td><input type="text" name="db_name" value="<?=@$_POST['db_name'];?>"></td>
        </tr>
        <tr>
            <th>User:</th>
            <td><input type="text" name="db_user" value="<?=@$_POST['db_user'];?>"></td>
        </tr>
        <tr>
            <th>Password:</th>
            <td><input type="password" name="db_pass" value=""></td>
        </tr>
        <tr>
            <th>Db charset:</th>
            <td><input type="text" name="db_charset" value="<?=@$_POST['db_charset'];?>" size="10"> (optional)</td>
        </tr>
        <tr>
            <th>Page charset:</th>
            <td><input type="text" name="page_charset" value="<?=@$_POST['page_charset'];?>" size="10"> (optional)</td>
        </tr>
        <tr>
            <td colspan="2" class="none" style="padding: 0; background: none; padding-top: 0.3em;">
                <table cellspacing="0" cellpadding="0"><tr><td>
                <input type="checkbox" name="remember" id="remember" value="1" <?=checked(@$_POST['remember']);?>></td><td>
                <label for="remember">remember me on this computer</label></td></tr></table>
            </td>
        </tr>
        <tr>
            <td class="none" colspan="2" style="padding-top: 0.4em;"><input type="submit" value="Connect"></td>
        </tr>
        </form>

        </body>
        </html>

    <?php
    
    exit;
}

db_connect($db_server, $db_name, $db_user, $db_pass);

if ($db_charset && 'mysql' == $db_driver) {
    db_exe("SET NAMES $db_charset");
}

if (@$_GET['dump_all'] == 1)
{
    dump_all($data = false);
}
if (@$_GET['dump_all'] == 2)
{
    dump_all($data = true);
}
if (@$_GET['dump_table'])
{
    dump_table($_GET['dump_table']);
}
if (@$_POST['sqlfile'])
{
    $files = sql_files_assoc();
    if (!isset($files[$_POST['sqlfile']])) {
        exit('File not found. md5 = '.$_POST['sqlfile']);
    }
    $sqlfile = $files[$_POST['sqlfile']];
    layout();
    echo '<div>Importing: <b>'.$sqlfile.'</b> ('.size(filesize($sqlfile)).')</div>';
    echo '<div>Database: <b>'.$db_name.'</b></div>';
    flush();
    import($sqlfile, @$_POST['ignore_errors'], @$_POST['transaction'], @$_POST['force_myisam'], (int) @$_POST['query_start']);
    exit;
}
if (@$_POST['drop_table'])
{
    db_exe('DROP TABLE '.$_POST['drop_table']);
    header('Location: '.$_SERVER['PHP_SELF']);
    exit;
}
function db_connect($db_server, $db_name, $db_user, $db_pass)
{
    global $db_driver, $db_link, $db_test;
    if (!extension_loaded($db_driver)) {
        trigger_error($db_driver.' extension not loaded', E_USER_ERROR);
    }
    if ('mysql' == $db_driver)
    {
        $db_link = @mysql_connect($db_server, $db_user, $db_pass);
        if (!is_resource($db_link)) {
            if ($db_test) {
                $db_test = 'mysql_connect() failed: '.db_error();
                return;
            } else {
                die('mysql_connect() failed: '.db_error());
            }
        }
        if (!@mysql_select_db($db_name, $db_link)) {
            $error = db_error();
            db_close();
            if ($db_test) {
                $db_test = 'mysql_select_db() failed: '.$error;
                return;
            } else {
                cookie_del('db_pass');
                die('mysql_select_db() failed: '.$error);
            }
        }
    }
    if ('pgsql' == $db_driver)
    {
        $conn = sprintf('host=%s dbname=%s user=%s password=%s', $db_server, $db_name, $db_user, $db_pass);
        $db_link = @pg_connect($conn);
        if (!is_resource($db_link)) {
            if ($db_test) {
                $db_test = 'pg_connect() failed: '.db_error();
                return;
            } else {
                cookie_del('db_pass');
                die('pg_connect() failed: '.db_error());
            }
        }
    }
    register_shutdown_function('db_cleanup');
}
function db_cleanup()
{
    db_close();
}
function db_close()
{
    global $db_driver, $db_link;
    if (is_resource($db_link)) {
        if ('mysql' == $db_driver) {
            mysql_close($db_link);
        }
        if ('pgsql' == $db_driver) {
            pg_close($db_link);
        }
    }
}
function db_query($query)
{
    global $db_driver, $db_link;
    if ('mysql' == $db_driver)
    {
        $rs = mysql_query($query, $db_link);
        return $rs;
    }
    if ('pgsql' == $db_driver)
    {
        $rs = pg_query($db_link, $query);
        return $rs;
    }
}
function db_exe($query)
{
    $rs = db_query($query);
    db_free($rs);
}
function db_one($query)
{
    $row = db_row_num($query);
    if ($row) {
        return $row[0];
    } else {
        return false;
    }
}
function db_row($query)
{
    global $db_driver, $db_link;
    if ('mysql' == $db_driver)
    {
        if (db_is_result($query)) {
            $rs = $query;
            return mysql_fetch_assoc($rs);
        } else {
            $query = db_limit($query, 0, 1);
            $rs = db_query($query);
            $row = mysql_fetch_assoc($rs);
            db_free($rs);
            if ($row) {
                return $row;
            }
        }
        return false;
    }
    if ('pgsql' == $db_driver)
    {
        if (db_is_result($query)) {
            $rs = $query;
            return pg_fetch_assoc($rs);
        } else {
            $query = db_limit($query, 0, 1);
            $rs = db_query($query);
            $row = pg_fetch_assoc($rs);
            db_free($rs);
            if ($row) {
                return $row;
            }
        }
        return false;
    }
}
function db_row_num($query)
{
    global $db_driver, $db_link;
    if ('mysql' == $db_driver)
    {
        if (db_is_result($query)) {
            $rs = $query;
            return mysql_fetch_row($rs);
        } else {
            $rs = db_query($query);
            $row = mysql_fetch_row($rs);
            db_free($rs);
            if ($row) {
                return $row;
            }
            return false;
        }
    }
    if ('pgsql' == $db_driver)
    {
        if (db_is_result($query)) {
            $rs = $query;
            return pg_fetch_row($rs);
        } else {
            $rs = db_query($query);
            $row = pg_fetch_row($rs);
            db_free($rs);
            if ($row) {
                return $row;
            }
            return false;
        }
    }
}
function db_list($query)
{
    global $db_driver, $db_link;
    $rs = db_query($query);
    $ret = array();
    while ($row = db_row($rs)) {
        $ret[] = $row;
    }
    db_free($rs);
    return $ret;
}
function db_assoc($query)
{
    global $db_driver, $db_link;
    $rs = db_query($query);
    $rows = array();
    $num = db_row_num($rs);
    if (!array_key_exists(0, $num)) {
        return array();
    }
    if (1 == count($num)) {
        $rows[] = $num[0];
        while ($num = db_row_num($rs)) {
            $rows[] = $num[0];
        }
        return $rows;
    }
    if ('mysql' == $db_driver)
    {
        mysql_data_seek($rs, 0);
    }
    if ('pgsql' == $db_driver)
    {
        pg_result_seek($rs, 0);
    }
    $row = db_row($rs);
    if (!is_array($row)) {
        return array();
    }
    if (count($num) < 2) {
        trigger_error(sprintf('db_assoc() failed. Two fields required. Query: %s.', $query), E_USER_ERROR);
    }
    if (count($num) > 2 && count($row) <= 2) {
        trigger_error(sprintf('db_assoc() failed. If specified more than two fields, then each of them must have a unique name. Query: %s.', $query), E_USER_ERROR);
    }
    foreach ($row as $k => $v) {
        $first_key = $k;
        break;
    }
    if (count($row) > 2) {
        $rows[$row[$first_key]] = $row;
        while ($row = db_row($rs)) {
            $rows[$row[$first_key]] = $row;
        }
    } else {
        $rows[$num[0]] = $num[1];
        while ($num = db_row_num($rs)) {
            $rows[$num[0]] = $num[1];
        }
    }
    db_free($rs);
    return $rows;
}
function db_limit($query, $offset, $limit)
{
    return $query." LIMIT $limit OFFSET $offset";
}
function db_escape($value)
{
    global $db_driver, $db_link;
    if ('mysql' == $db_driver) {
        return mysql_real_escape_string($value, $db_link);
    }
    if ('pgsql' == $db_driver) {
        return pg_escape_string($value);
    }
}
function db_quote($s)
{
    switch (true) {
        case is_null($s):   return 'NULL';
        case is_int($s):    return $s;
        case is_float($s):  return $s;
        case is_bool($s):   return (int) $s;
        case is_string($s): return "'" . db_escape($s) . "'";
        case is_object($s): return $s->getValue();
        default: 
            trigger_error(sprintf("db_quote() failed. Invalid data type: '%s'.", gettype($s)), E_USER_ERROR);
            return false;
    }
}
function db_free($rs)
{
    global $db_driver;
    if (db_is_result($rs)) {
        if ('mysql' == $db_driver) return mysql_free_result($rs);
        if ('pgsql' == $db_driver) return pg_free_result($rs);
    }
}
function db_is_result($rs)
{
    global $db_driver;
    if ('mysql' == $db_driver) return is_resource($rs);
    if ('pgsql' == $db_driver) return is_object($rs) || is_resource($rs);
}
function db_error()
{
    global $db_driver, $db_link;
    if ('mysql' == $db_driver) {
        if (is_resource($db_link)) {
            return mysql_error($db_link). ' ('. mysql_errno($db_link).')';
        } else {
            return mysql_error(). ' ('. mysql_errno().')';
        }
    }
    if ('pgsql' == $db_driver) {
        if (is_resource($db_link)) {
            return pg_last_error($db_link);
        }
    }
}
function db_begin()
{
    global $db_driver;
    if ('mysql' == $db_driver) {
        db_exe('SET AUTOCOMMIT=0');
        db_exe('BEGIN');
    }
    if ('pgsql' == $db_driver) {
        db_exe('BEGIN');
    }
}
function db_end()
{
    global $db_driver;
    if ('mysql' == $db_driver) {
        db_exe('COMMIT');
        db_exe('SET AUTOCOMMIT=1');
    }
    if ('pgsql' == $db_driver) {
        db_exe('COMMIT');
    }
}
function db_rollback()
{
    global $db_driver;
    if ('mysql' == $db_driver) {
        db_exe('ROLLBACK');
        db_exe('SET AUTOCOMMIT=1');
    }
    if ('pgsql' == $db_driver) {
        db_exe('ROLLBACK');
    }
}
function db_in_array($arr)
{
    $in = '';
    foreach ($arr as $v) {
        if ($in) $in .= ',';
        $in .= db_quote($v);
    }
    return $in;
}
function list_dbs()
{
    global $db_driver;
    if ('mysql' == $db_driver)
    {
        $rs = db_query("SHOW DATABASES");
        $ret = array();
        while ($row = db_row_num($rs)) {
            $db = strtolower($row[0]);
            $ret[$db] = $db;
        }
        return $ret;
    }
    if ('pgsql' == $db_driver)
    {
        return db_assoc('SELECT LOWER(datname), LOWER(datname) FROM pg_database');
    }
}
function list_tables()
{
    global $db_driver, $db_link, $db_name;
    static $cache;
    if (isset($cache)) {
        return $cache;
    }
    if ('mysql' == $db_driver)
    {
        $result = mysql_list_tables($db_name, $db_link);
        $num = mysql_num_rows($result);
        $i = 0;
        $tables = array();
        for ($i = 0; $i < $num; $i++) {
            $tablename = mysql_tablename($result, $i);
            $tables[$i] = $tablename;
        }
        $cache = $tables;
        return $tables;
    }
    if ('pgsql' == $db_driver)
    {
        $tables = db_assoc("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_type = 'BASE TABLE' ORDER BY table_name");
        $cache = $tables;
        return $tables;
    }
}
function table_structure($table)
{
    global $db_driver;
    if ('mysql' == $db_driver)
    {
        $query = "SHOW CREATE TABLE `$table`";
        $row = db_row_num($query);
        echo $row[1].';';
        echo "\r\n\r\n";
    }
    if ('pgsql' == $db_driver)
    {
        return '';
    }
}
function table_data($table)
{
    global $db_driver;
    set_time_limit(0);
    $query = "SELECT * FROM $table";
    $result = db_query($query);
    $count = 0;
    while ($row = db_row($result))
    {
        if ('mysql' == $db_driver) {
            echo 'INSERT INTO `'.$table.'` VALUES (';
        }
        if ('pgsql' == $db_driver) {
            echo 'INSERT INTO '.$table.' VALUES (';
        }
        $x = 0;
        foreach($row as $key => $value)
        { 
            if ($x == 1) { echo ', '; }
            else  { $x = 1; }
            if (is_numeric($value)) { echo "'".$value."'"; }
            elseif (is_null($value))  { echo 'NULL'; }
            else { echo '\''. escape($value) .'\''; }
        }
        echo ");\r\n";
        $count++;
        if ($count % 100 == 0) { flush(); }
    }
    db_free($result);
    echo "\r\n";
}
function table_status()
{
    global $db_driver, $db_link, $db_name;
    if ('mysql' == $db_driver)
    {
        $status = array();
        $status['total_size'] = 0;
        $result = mysql_query("SHOW TABLE STATUS FROM $db_name", $db_link);
        while ($row = mysql_fetch_assoc($result)) {
            $status['total_size'] += $row['Data_length']; // + Index_length
            $status[$row['Name']]['size'] = $row['Data_length'];
            $status[$row['Name']]['count'] = $row['Rows'];
        }
        return $status;
    }
    if ('pgsql' == $db_driver)
    {
        $status = array();
        $status['total_size'] = 0;
        $tables_in = db_in_array(list_tables());
        $rels = db_list("SELECT relname, reltuples, (relpages + 1) * 8 * 2 * 1024 AS relsize FROM pg_class WHERE relname IN ($tables_in)");
        foreach ($rels as $rel) {
            $status['total_size'] += $rel['relsize'];
            $status[$rel['relname']]['size'] = $rel['relsize'];
            $status[$rel['relname']]['count'] = $rel['reltuples'];
        }
        return $status;
    }
}
function table_columns($table)
{
    static $cache = array();
    if (isset($cache[$table])) {
        return $cache[$table];
    }
    $row = db_row("SELECT * FROM $table");
    if (!$row) {
        $cache[$table] = false;
        return false;
    }
    foreach ($row as $k => $v) {
        $row[$k] = $k;
    }
    $cache[$table] = $row;
    return $row;
}
function table_types($table)
{
    global $db_driver;
    if ('mysql' == $db_driver)
    {
        $rows = db_list("SHOW COLUMNS FROM $table");
        $types = array();
        foreach ($rows as $row) {
            $type = $row['Type'];
            $types[$row['Field']] = $type;
        }
        return $types;
    }
    if ('pgsql' == $db_driver)
    {
        return db_assoc("SELECT column_name, udt_name FROM information_schema.columns WHERE table_name ='$table' ORDER BY ordinal_position");
    }
}
function table_types2($table)
{
    global $db_driver;
    if ('mysql' == $db_driver)
    {
        $rows = db_list("SHOW COLUMNS FROM $table");
        $types = array();
        foreach ($rows as $row) {
            $type = $row['Type'];
            preg_match('#^\w+#', $type, $match);
            $type = $match[0];
            $types[$row['Field']] = $type;
        }
        return $types;
    }
    if ('pgsql' == $db_driver)
    {
        return db_assoc("SELECT column_name, udt_name FROM information_schema.columns WHERE table_name ='$table' ORDER BY ordinal_position");
    }
}
function table_types_group($types)
{
    foreach ($types as $k => $type) {
        preg_match('#^\w+#', $type, $match);
        $type = $match[0];
        $types[$k] = $type;
    }
    $types = array_unique($types);
    $types = array_values($types);
    $types2 = array();
    foreach ($types as $type) {
        $types2[$type] = $type;
    }
    return $types2;
}
function table_pk($table)
{
    $cols = table_columns($table);
    if (!$cols) return null;
    foreach ($cols as $col) {
        return $col;
    }
}
function escape($text)
{
    $text = addslashes($text);
    $search = array("\r", "\n", "\t");
    $replace = array('\r', '\n', '\t');
    return str_replace($search, $replace, $text);
}
function dump_table($table)
{
    set_time_limit(0);
    global $db_name;
    header("Cache-control: private");
    header("Content-type: application/octet-stream");
    header('Content-Disposition: attachment; filename='.$db_name.'_'.$table.'.sql');
    table_structure($table);
    table_data($table);
    exit;
}
function dump_all($data = false)
{
    set_time_limit(0);
    global $db_name;
    header("Cache-control: private");
    header("Content-type: application/octet-stream");
    header('Content-Disposition: attachment; filename='.date('Ymd').'_'.$db_name.'.sql');
    $tables = list_tables();
    foreach ($tables as $key => $value)
    {
        table_structure($value);
        if ($data) {
            table_data($value);
        }
        flush();
    }
    exit;
}
function import($file, $ignore_errors = false, $transaction = false, $force_myisam = false, $query_start = false)
{
    global $db_driver, $db_link, $db_charset;
    if ($ignore_errors && $transaction) {
        echo '<div>You cannot select both: ignoring errors and transaction</div>';
        exit;
    }

    $count_errors = 0;
    set_time_limit(0);
    $fp = fopen($file, 'r');
    if (!$fp) { exit('fopen('.$file.') failed'); }
    flock($fp, 1);
    $text = trim(fread($fp, filesize($file)));
    flock($fp, 3);
    fclose($fp);
    if ($db_charset == 'latin2') {
        $text = charset_fix($text);
    }
    if ($force_myisam) {
        $text = preg_replace('#TYPE\s*=\s*InnoDB#i', 'TYPE=MyISAM', $text);
    }
    $text = preg_split("#;(\r\n|\n|\r)#", $text);
    $x = 0;
    echo '<div>Ignoring errors: <b>'.($ignore_errors?'Yes':'No').'</b></div>';
    echo '<div>Transaction: <b>'.($transaction?'Yes':'No').'</b></div>';
    echo '<div>Force MyIsam: <b>'.($force_myisam?'Yes':'No').'</b></div>';
    echo '<div>Query start: <b>#'.$query_start.'</b></div>';
    echo '<div>Queries found: <b>'.count($text).'</b></div>';
    echo '<div>Executing ...</div>';
    flush();

    if ($transaction) {
        echo '<div>BEGIN;</div>';
        db_begin();
    }

    $time = time_start();
    $query_start = (int) $query_start;
    if (!$query_start) {
        $query_start = 1;
    }
    $query_no = 0;

    foreach($text as $key => $value)
    {
        $x++;
        $query_no++;
        if ($query_start > $query_no) {
            continue;
        }

        if ('mysql' == $db_driver)
        {
            $result = @mysql_query($value.';', $db_link);
        }
        if ('pgsql' == $db_driver)
        {
            $result = @pg_query($db_link, $value.';');
        }
        if(!$result) {
            $x--;
            if (!$count_errors) {
                echo '<table cellspacing="1"><tr><th width="25%">Error</th><th>Query</th></tr>';
            }
            $count_errors++;
            echo '<tr><td>#'.$query_no.' '.db_error() .')'.'</td><td>'.nl2br(html_once($value)).'</td></tr>';
            flush();
            if (!$ignore_errors) {
                echo '</table>';
                echo '<div><span style="color: red;"><b>Import failed.</b></span></div>';
                echo '<div>Queries executed: <b>'.($x-$query_start+1).'</b>.</div>';
                if ($transaction) {
                    echo '<div>ROLLBACK;</div>';
                    db_rollback();
                }
                echo '<br><div><a href="'.$_SERVER['PHP_SELF'].'?import=1">&lt;&lt; go back</a></div>';
                exit;
            }
        }
    }
    if ($count_errors) {
        echo '</table>';
    }
    if ($transaction) {
        echo '<div>COMMIT;</div>';
        db_end();
    }
    echo '<div><span style="color: green;"><b>Import finished.</b></span></div>';
    echo '<div>Queries executed: <b>'.($x-$query_start+1).'</b>.</div>';
    echo '<div>Time: <b>'.time_end($time).'</b> sec</div>';
    echo '<br><div><a href="'.$_SERVER['PHP_SELF'].'?import=1">&lt;&lt; go back</a></div>';
}
function layout()
{
    ?>
        <style>
        body,table,input,select { font-family: tahoma; font-size: 11px; }
        body { margin: 1em; padding: 0; margin-top: 0.5em; }
        h1, h2 { font-family: arial; margin: 1em 0; }
        h1 { font-size: 150%; margin: 0.7em 0; }
        h2 { font-size: 125%; }
        th { background: #ccc; }
        td { background: #f5f5f5; }
        th, td { padding: 0.1em 0.5em; }
        p { margin: 1em 0; }
        form { margin: 0; }
        form th { text-align: left; }
        a, a:visited { text-decoration: none; }
        a:hover { text-decoration: underline; }
        form .none td, form .none th { background: none; padding: 0 0.25em; }
        .none { background: none; padding-top: 0.7em; }
        </style>
        <script>
        function popup(url, width, height, more)
        {
            if (!width) width = 400;
            if (!height) height = 400;
            var x = (screen.width/2-width/2);
            var y = (screen.height/2-height/2);
            window.open(url, "", "scrollbars=yes,resizable=yes,width="+width+",height="+height+",screenX="+(x)+",screenY="+y+",left="+x+",top="+y+(more ? ","+more : ""));
        }
        </script>
    <?php
}
function conn_info()
{
    global $db_driver, $db_server, $db_name, $db_user, $db_charset, $page_charset, $charset1, $charset2;
    $dbs = list_dbs();
    $db_name = strtolower($db_name);
    ?>
    <p>
        Driver: <b><?=$db_driver;?></b>
        &nbsp;-&nbsp;
        Server: <b><?=$db_server;?></b>
        &nbsp;-&nbsp;
        Database: <select name="db_name" onchange="location='<?=$_SERVER['PHP_SELF'];?>?db_name='+this.value"><?=options($dbs, $db_name);?></select>
        &nbsp;-&nbsp;
        <a href="javascript:void(0)" onclick="popup('<?=$_SERVER['PHP_SELF'];?>?execute_sql=1', 600, 400)">Execute SQL</a>
        &nbsp;-&nbsp;
        User: <b><?=$db_user;?></b>
        &nbsp;-&nbsp;
        Password: <b>****</b>
        &nbsp;-&nbsp;
        Db charset: <select name="db_charset" onchange="location='<?=$_SERVER['PHP_SELF'];?>?db_charset='+this.value+'&from=<?=urlencode($_SERVER['REQUEST_URI']);?>'">
        <option value=""></option><?=options($charset1, $db_charset);?></select>
        &nbsp;-&nbsp;
        Page charset: <select name="page_charset" onchange="location='<?=$_SERVER['PHP_SELF'];?>?page_charset='+this.value+'&from=<?=urlencode($_SERVER['REQUEST_URI']);?>'">
        <option value=""></option><?=options($charset2, $page_charset);?></select>
        &nbsp;-&nbsp;
        <a href="<?=$_SERVER['PHP_SELF'];?>?disconnect=1">Disconnect</a>
    </p>
    <?php
}
function size($bytes)
{
    $base     = 1024;
    $suffixes = array(' B', ' kB', ' MB', ' GB', ' TB', ' PB', ' EB');
    $usesuf = 0;
    $n = (float) $bytes;
    while ($usesuf < 2) {
        $n /= (float) $base;
        ++$usesuf;
    }
    $places = 2 - floor(log10($n));
    $places = max($places, 0);
    $retval = number_format($n, $places, '.', '');
    if (substr($retval, -2) === '.0') {
        $retval = substr($retval, 0, -2);
    }
    if (substr($retval, -3) === '.00') {
        $retval = substr($retval, 0, -3);
    }
    $retval = round($retval, 2);
    $retval = pad_zeros($retval, 2);
    return $retval . $suffixes[$usesuf];
}
function html($s)
{
    $html = array(
        '&' => '&amp;',
        '<' => '&lt;',
        '>' => '&gt;',
        '"' => '&quot;',
        '\'' => '&#039;'
    );
    $s = preg_replace('/&#(\d+)/', '@@@@@#$1', $s);
    $s = str_replace(array_keys($html), array_values($html), $s);
    $s = preg_replace('/@@@@@#(\d+)/', '&#$1', $s);
    return trim($s);
}
function html_undo($s)
{
    $html = array(
        '&' => '&amp;',
        '<' => '&lt;',
        '>' => '&gt;',
        '"' => '&quot;',
        '\'' => '&#039;'
    );
    return str_replace(array_values($html), array_keys($html), $s);
}
function html_once($s)
{
    $s = html_undo($s);
    return html($s);
}
function str_truncate($string, $length, $etc = ' ..', $break_words = true)
{
    if ($length == 0) {
        return '';
    }
    if (strlen($string) > $length + strlen($etc)) {
        if (!$break_words) {
	        $string = preg_replace('/\s+?(\S+)?$/', '', substr($string, 0, $length+1));
        }
        return substr($string, 0, $length) . $etc;
    }
    return $string;
}
function dir_read($dir, $ignore_ext = array(), $allow_ext = array())
{
    if (is_null($ignore_ext)) $ignore_ext = array();
    if (is_null($allow_ext)) $allow_ext = array();
    foreach ($allow_ext as $k => $ext) {
        $allow_ext[$k] = str_replace('.', '', $ext);
    }

    $ret = array();
    if ($handle = opendir($dir)) {
        while (($file = readdir($handle)) !== false) {
            if ($file != '.' && $file != '..') {
                $ignore = false;
                foreach ($ignore_ext as $ext) {
                    if (file_ext_has($file, $ext)) {
                        $ignore = true;
                    }
                }
                if (is_array($allow_ext) && count($allow_ext) && !in_array(file_ext($file), $allow_ext)) {
                    $ignore = true;
                }
                if (!$ignore) {
                    $ret[] = $dir.'/'.$file;
                }
            }
        }
        closedir($handle);
    }
    return $ret;
}
function options($options, $selected = null, $ignore_type = false)
{
    $ret = '';
    foreach ($options as $k => $v) {
        //str_replace('"', '\"', $k)
        $ret .= '<option value="'.html_once($k).'"';
        if ((is_array($selected) && in_array($k, $selected)) || (!is_array($selected) && $k == $selected && $selected !== '' && $selected !== null)) {
            if ($ignore_type) {
                $ret .= ' selected="selected"';
            } else {
                if (!(is_numeric($k) xor is_numeric($selected))) {
                    $ret .= ' selected="selected"';
                }
            }
        }
        $ret .= '>'.htmlspecialchars(strip_tags($v)).' </option>';
    }
    return $ret;
}
function sql_files()
{
    $files = dir_read('.', null, array('.sql'));
    $files2 = array();
    foreach ($files as $file) {
        $files2[md5($file)] = $file.sprintf(' (%s)', size(filesize($file)));
    }
    return $files2;
}
function sql_files_assoc()
{
    $files = dir_read('.', null, array('.sql'));
    $files2 = array();
    foreach ($files as $file) {
        $files2[md5($file)] = $file;
    }
    return $files2;
}
function file_ext($name)
{
    $ext = null;
    if (($pos = strrpos($name, '.')) !== false) {
        $len = strlen($name) - ($pos+1);
        $ext = substr($name, -$len);
        if (!preg_match('#^[a-z0-9]+$#i', $ext)) {
            return null;
        }
    }
    return $ext;
}
function checked($bool)
{
    if ($bool) return 'checked="checked"';
}
function url_offset($offset)
{
    $url = $_SERVER['REQUEST_URI'];
    if (preg_match('#&offset=\d+#', $url)) {
        $url = preg_replace('#&offset=\d+#', '&offset='.$offset, $url);
    } else {
        $url .= '&offset='.$offset;
    }
    return $url;
}
function str_wrap($s, $width, $break = ' ', $omit_tags = false)
{
    //$restart = array(' ', "\t", "\r", "\n");
    $restart = array();
    $cnt = 0;
    $ret = '';
    $open_tag = false;
    for ($i=0; $i<strlen($s); $i++)
    {
        $char = $s{$i};

        if ($omit_tags)
        {
            if ($char == '<') {
                $open_tag = true;
            }
            if ($char == '>') {
                $open_tag = false;
            }
            if ($open_tag) {
                $ret .= $char;
                continue;
            }
        }

        if (in_array($char, $restart)) {
            $cnt = 0;
        } else {
            $cnt++;
        }
        $ret .= $char;
        if ($cnt > $width) {
            $ret .= $break;
            $cnt = 0;
        }
    }
    return $ret;
}
function time_micro() 
{ 
    list($usec, $sec) = explode(" ", microtime()); 
    return ((float)$usec + (float)$sec); 
}
function time_start()
{
    return time_micro();
}
function time_end($start)
{
    $end = time_micro();
    $end = round($end - $start, 3);
    $end = pad_zeros($end, 3);
    return $end;
}
function str_has($str, $needle, $ignore_case = false)
{
    if (is_array($needle)) {
        foreach ($needle as $n) {
            if (!str_has($str, $n, $ignore_case)) {
                return false;
            }
        }
        return true;
    }
    if ($ignore_case) {
        $str = str_lower($str);
        $needle = str_lower($needle);
    }
    return strpos($str, $needle) !== false;
}
function pad_zeros($number, $zeros)
{
    if (str_has($number, '.')) {
        preg_match('#\.(\d+)$#', $number, $match);
        $number .= str_repeat('0', $zeros-strlen($match[1]));
        return $number;
    } else {
        return $number.'.'.str_repeat('0', $zeros);
    }
}
function charset_fix_invalid($s)
{
    $fix = '�Ⓞ�������';
    $s = str_replace(str_array($fix), '', $s);
    return $s;
}
function charset_is_invalid($s)
{
    $fix = '�Ⓞ�������';
    $fix = str_array($fix);
    foreach ($fix as $char) {
        if (str_has($s, $char)) {
            return true;
        }
    }
    return false;
}
function charset_fix($string)
{
    // UTF-8 && WIN-1250 => ISO-8859-2
    // todo: is checking required? redundant computing?
    if (charset_win_is($string)) {
        $string = charset_win_fix($string);
    }
    if (charset_utf_is($string)) {
        $string = charset_utf_fix($string);
    }
    return $string;
}
function charset_win_is($string)
{
    $win = '�����ʳ����Ӝ�����';
    $iso = '�����ʳ����Ӷ�����';
    for ($i=0; $i<strlen($win); $i++) {
        if ($win{$i} != $iso{$i}) {
            if (strstr($string, $win{$i}) !== false) {
                return true;
            }
        }
    }
    return false;
}
function charset_win_fix($string)
{
    $win = '�����ʳ����Ӝ�����';
    $iso = '�����ʳ����Ӷ�����';
    $srh = array();
    $rpl = array();
    for ($i = 0; $i < strlen($win); $i++) {
        if ($win{$i} != $iso{$i}) {
            $srh[] = $win{$i};
            $rpl[] = $iso{$i};
        }
    }
    $string = str_replace($srh, $rpl, $string);
    return $string;
}
function charset_utf_is($string)
{
    $utf_iso = array(
       "\xc4\x85" => "\xb1",
       "\xc4\x84" => "\xa1",
       "\xc4\x87" => "\xe6",
       "\xc4\x86" => "\xc6",
       "\xc4\x99" => "\xea",
       "\xc4\x98" => "\xca",
       "\xc5\x82" => "\xb3",
       "\xc5\x81" => "\xa3",
       "\xc3\xb3" => "\xf3",
       "\xc3\x93" => "\xd3",
       "\xc5\x9b" => "\xb6",
       "\xc5\x9a" => "\xa6",
       "\xc5\xba" => "\xbc",
       "\xc5\xb9" => "\xac",
       "\xc5\xbc" => "\xbf",
       "\xc5\xbb" => "\xaf",
       "\xc5\x84" => "\xf1",
       "\xc5\x83" => "\xd1",
        // xmlhttprequest utf-8 encoding
       "%u0104" => "\xA1",
       "%u0106" => "\xC6",
       "%u0118" => "\xCA",
       "%u0141" => "\xA3",
       "%u0143" => "\xD1",
       "%u00D3" => "\xD3",
       "%u015A" => "\xA6",
       "%u0179" => "\xAC",
       "%u017B" => "\xAF",
       "%u0105" => "\xB1",
       "%u0107" => "\xE6",
       "%u0119" => "\xEA",
       "%u0142" => "\xB3",
       "%u0144" => "\xF1",
       "%u00D4" => "\xF3",
       "%u015B" => "\xB6",
       "%u017A" => "\xBC",
       "%u017C" => "\xBF"
    );
    foreach ($utf_iso as $k => $v) {
        if (strpos($string, $k) !== false) {
            return true;
        }
    }
    return false;
}
function charset_utf_fix($string)
{
    $utf_iso = array(
       "\xc4\x85" => "\xb1",
       "\xc4\x84" => "\xa1",
       "\xc4\x87" => "\xe6",
       "\xc4\x86" => "\xc6",
       "\xc4\x99" => "\xea",
       "\xc4\x98" => "\xca",
       "\xc5\x82" => "\xb3",
       "\xc5\x81" => "\xa3",
       "\xc3\xb3" => "\xf3",
       "\xc3\x93" => "\xd3",
       "\xc5\x9b" => "\xb6",
       "\xc5\x9a" => "\xa6",
       "\xc5\xba" => "\xbc",
       "\xc5\xb9" => "\xac",
       "\xc5\xbc" => "\xbf",
       "\xc5\xbb" => "\xaf",
       "\xc5\x84" => "\xf1",
       "\xc5\x83" => "\xd1",
        // xmlhttprequest uses different encoding
       "%u0104" => "\xA1",
       "%u0106" => "\xC6",
       "%u0118" => "\xCA",
       "%u0141" => "\xA3",
       "%u0143" => "\xD1",
       "%u00D3" => "\xD3",
       "%u015A" => "\xA6",
       "%u0179" => "\xAC",
       "%u017B" => "\xAF",
       "%u0105" => "\xB1",
       "%u0107" => "\xE6",
       "%u0119" => "\xEA",
       "%u0142" => "\xB3",
       "%u0144" => "\xF1",
       "%u00D4" => "\xF3",
       "%u015B" => "\xB6",
       "%u017A" => "\xBC",
       "%u017C" => "\xBF"
    );
    return str_replace(array_keys($utf_iso), array_values($utf_iso), $string);
}
function layout_start($title='')
{
    global $page_charset;
    ?>

    <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
    <html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=<?=$page_charset;?>">
        <title><?=$title;?></title>
    </head>
    <body>

    <? layout(); ?>

    <?php
}
function layout_end()
{
    ?>
    </body>
    </html>
    <?php
}

?>
<?php if (rget('import')): ?>

    <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
    <html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=<?=$page_charset;?>">
        <title>Database: <?=$db_name;?> &gt; Import</title>
    </head>
    <body>

    <?php layout(); ?>
    <h1><a href="<?=$_SERVER['PHP_SELF'];?>">Database: <?=$db_name;?></a> &gt; Import</h1>
    <?php conn_info(); ?>

    <?php $files = sql_files(); ?>

    <?php if (count($files)): ?>
        <form action="<?=$_SERVER['PHP_SELF'];?>" method="post">
        <table class="none" cellspacing="0" cellpadding="0">
        <tr>
            <td>SQL file:</th>
            <td><select name="sqlfile"><option value="" selected="selected"></option><?=options($files);?></select></td>
            <td><input type="checkbox" name="ignore_errors" id="ignore_errors" value="1"></td>
            <td><label for="ignore_errors">ignore errors</label></td>
            <td><input type="checkbox" name="transaction" id="transaction" value="1"></td>
            <td><label for="transaction">transaction</label></td>
            <td><input type="checkbox" name="force_myisam" id="force_myisam" value="1"></td>
            <td><label for="force_myisam">force myisam</label></td>
            <td><input type="text" size="5" name="query_start" value=""></td>
            <td>query start</td>
            <td><input type="submit" value="Import"></td>
        </tr>
        </table>
        </form>
        <br>
    <?php else: ?>
        No sql files found in current directory.
    <?php endif; ?>

    </body></html>

<?php exit; endif; ?>
<?php if (@$_GET['execute_sql']): ?>
<?php
    
    $template = @$_GET['template'];
    $perform = @$_POST['perform'];
    $error = '';
    $msg = '';

    if ('POST' == $_SERVER['REQUEST_METHOD'])
    {
        if (!$perform) {
            $error = 'No action selected.';
        }
        if (!$error)
        {
            switch ($perform) {
                case 'execute':
                    $_POST['count_query']++;
                    $sql = $_POST['sql'];
                    $sql = trim($sql);
                    if ($sql) {
                        if ('mysql' == $db_driver)
                        {
                            $rs = @mysql_query($sql, $db_link);
                        }
                        if ('pgsql' == $db_driver)
                        {
                            $rs = @pg_query($db_link, $sql);
                        }
                        if ($rs) {
                            if ($rs === true) {
                                $msg = '';
                                if ('mysql' == $db_driver)
                                {
                                    $affected = mysql_affected_rows($db_link);
                                    $msg .= '<b>'.$affected.'</b> rows affected.';
                                }
                            } else {
                                if ('pgsql' == $db_driver)
                                {
                                    $affected = @pg_affected_rows($rs);
                                    if ($affected) {
                                        $msg .= '<b>'.$affected.'</b> rows affected. ';
                                    }
                                }
                                $msg .= 'Result: '.$rs;
                            }
                            db_free($rs);
                        } else {
                            $error = db_error();
                        }
                    } else {
                        $error = 'No query found.';
                    }
                    break;
            }
        }
    }

?>

    <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
    <html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=<?=$page_charset;?>">
        <title>Database: <?=$db_name;?> &gt; Execute SQL</title>
    </head>
    <body>

        <? layout(); ?>
        <h1>Database: <?=$db_name;?> &gt; Execute SQL</h1>

        <? if ($perform == 'execute'): ?>
            <p>Executing query #<?=$_POST['count_query'];?>:</p>
        <? endif; ?>

        <div id="msg">

        <? if ($error): ?>
            <div style="background: #ffffd7; padding: 0.5em; border: #ccc 1px solid; margin-bottom: 1em;">
                <span style="color: red; font-weight: bold;">Error:</span>&nbsp;
                <?=$error;?>
            </div>
        <? endif; ?>

        <? if ($msg): ?>
            <div style="background: #ffffd7; padding: 0.5em; border: #ccc 1px solid; margin-bottom: 1em;">
                <span style="color: green; font-weight: bold;">Query executed.</span>&nbsp;
                <?=$msg;?>
            </div>
        <? endif; ?>

        </div>

        <script>
        function sql_submit(form)
        {
            if (sql_is_perform(form)) {
                return true;
            } else {
                return false;
            }
        }
        function sql_execute(form)
        {
            form.perform.value='execute';
            form.submit();
        }
        function sql_save(form)
        {
            form.perform.value='save';
            form.submit();
        }
        function sql_load(form)
        {
            form.perform.value='load';
            form.submit();
        }
        function sql_is_perform(form)
        {
            if (form.perform.value.length) {
                return true;
            }
            return false;
        }
        </script>

        <form action="<?=$_SERVER['PHP_SELF'];?>?execute_sql=1" method="post" onsubmit="return sql_submit(this);">
        <input type="hidden" name="count_query" value="<?=(int)@$_POST['count_query'];?>">
        <input type="hidden" name="perform" value="">
        <div><textarea name="sql" cols="65" rows="10"><?=html_once(@$_POST['sql']);?></textarea></div>
        <table class="none"><tr>
        <td valign="top">
            <div style="padding-top: 0.5em;"><input type="button" value="Execute" onclick="sql_execute(this.form);"></div>
        </td>
        <td valign="top">
            <div style="padding-top: 0.5em;" style="display: none;">
                Save template:
                <input type="text" name="save_template" value="<?=html_once($template);?>" size="20">
                <input type="button" value="  Save  " onclick="sql_save(this.form);">
            </div>
        </td>
        <td valign="top">
            <div style="padding-top: 0.5em;" style="display: none;">
                Load template:
                <select style="width: 100px;" name="load_template"><option value=""></option></select>
                <input type="button" value="  Load  " onclick="sql_load(this.form);">
            </div>
        </td>
        </tr></table>
        </form>

    </body>
    </html>

<?php exit; endif; ?>
<?php if (@$_GET['viewtable']): ?>

    <?
        $table = $_GET['viewtable'];
        $count = db_one("SELECT COUNT(*) FROM $table");

        $columns = table_columns($table);
        $columns2 = $columns;
        $types = table_types2($table);
        foreach ($columns2 as $k => $v) {
            $columns2[$k] = $v.' ('.$types[$k].')';
        }
        $types_group = table_types_group($types);

        $where = '';
        $found = $count;
        if (@$_GET['search']) {
            $search = $_GET['search'];
            $cols2 = array();
            
            if (@$_GET['column']) {
                $cols2[] = $_GET['column'];
            } else {
                $cols2 = $columns;
            }
            $where = '';
            $search = db_escape($search);
            
            $column_type = '';
            if (!@$_GET['column']) {
                $column_type = @$_GET['column_type'];
            } else {
                $_GET['column_type'] = '';
            }

            $ignore_int = false;

            foreach ($columns as $col)
            {
                if (!@$_GET['column'] && $column_type) {
                    if ($types[$col] != $column_type) {
                        continue;
                    }
                }
                if (!$column_type && !is_numeric($search) && str_has($types[$col], 'int')) {
                    $ignore_int = true;
                    continue;
                }
                if (@$_GET['column'] && $col != $_GET['column']) {
                    continue;
                }
                if ($where) { $where .= ' OR '; }
                if (is_numeric($search)) {
                    $where .= "$col = '$search'";
                } else {
                    if ('mysql' == $db_driver) {
                        $where .= "$col LIKE '%$search%'";
                    } else if ('pgsql' == $db_driver) {
                        $where .= "$col ILIKE '%$search%'";
                    } else {
                        trigger_error('db_driver not implemented');
                    }
                }
            }
            if ($ignore_int && !$where) {
                $where .= ' 1=2 ';
            }
            $where = 'WHERE '.$where;
        }

        if ($where) {
            $found = db_one("SELECT COUNT(*) FROM $table $where");
        }

        $limit = 50;
        $offset = (int) @$_GET['offset'];
        $page = floor($offset / $limit + 1);
        $pages = ceil($found / $limit);
        $pk = table_pk($table);
        
    ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=<?=$page_charset;?>">
    <title>Database: <?=$db_name;?> &gt; Table: <?=$table;?></title>
</head>
<body>

    <?php layout(); ?>

    <h1><a href="<?=$_SERVER['PHP_SELF'];?>">Database: <?=$db_name;?></a> &gt; Table: <?=$table;?></h1>

    <?php conn_info(); ?>

    <p>
        <a href="<?=$_SERVER['PHP_SELF'];?>">All tables</a>
        &nbsp;&gt;&nbsp;
        <a href="<?=$_SERVER['PHP_SELF'];?>?viewtable=<?=$table;?>"><b><?=$table;?></b></a> (<?=$count;?>)
    </p>

    <?php if ($count): ?>

        <form action="<?=$_SERVER['PHP_SELF'];?>" method="get" style="margin-bottom: 1em;">
        <input type="hidden" name="viewtable" value="<?=$table;?>">
        <table cellspacing="1">
        <tr>
            <td><input type="text" name="search" value="<?=html_once(@$_GET['search']);?>"></td>
            <td><select name="column"><option value=""></option><?=options($columns2, @$_GET['column']);?></select></td>
            <td><select name="column_type"><option value=""></option><?=options($types_group, @$_GET['column_type']);?></select></td>
            <td><input type="submit" value="Search"></td>
            <td>
                order by:
                <select name="order_by"><option value=""></option><?=options($columns, @$_GET['order_by']);?></select>
                <input type="checkbox" name="order_desc" id="order_desc" value="1" <?=checked(@$_GET['order_desc']);?>>
                <label for="order_desc">desc</label>
            </td>
            <td>
                <input type="checkbox" name="full_content" id="full_content" <?=checked(@$_GET['full_content']);?>>
                <label for="full_content">full content</label>
            </td>
            <td>
                <input type="checkbox" name="nl2br" id="nl2br" <?=checked(@$_GET['nl2br']);?>>
                <label for="nl2br">nl2br</label>
            </td>
        </tr>
        </table>
        </form>

        <? if ($count && $count != $found): ?>
            <p>Found: <b><?=$found;?></b></p>
        <? endif; ?>

        <?php if ($found): ?>

            <?php if ($pages > 1): ?>
            <p>
                <?php if ($page > 1): ?>
                    <a href="<?=url_offset(($page-1)*$limit-$limit);?>">&lt;&lt; Previous</a> &nbsp;
                <?php endif; ?>
                Page <b><?=$page;?></b> of <b><?=$pages;?></b> &nbsp; 
                <?php if ($pages > $page): ?>
                    <a href="<?=url_offset($page*$limit);?>">Next &gt;&gt;</a>
                <?php endif; ?>
            </p>
            <?php endif; ?>

            <?
                $order = "ORDER BY";
                if (@$_GET['order_by']) {
                    $order .= ' '.$_GET['order_by'];
                } else {
                    $order .= ' '.$pk;
                }
                if (@$_GET['order_desc']) { $order .= ' DESC'; }

                $rs = db_query("SELECT * FROM $table $where $order LIMIT $limit OFFSET $offset");
            ?>

            <script>
            function mark_row(tr)
            {
                var els = tr.getElementsByTagName('td');
                if (tr.marked) {
                    for (var i = 0; i < els.length; i++) {
                        els[i].style.backgroundColor = '';
                    }
                    tr.marked = false;
                } else {
                    tr.marked = true;
                    for (var i = 0; i < els.length; i++) {
                        els[i].style.backgroundColor = '#ddd';
                    }
                }
            }
            </script>

            <table cellspacing="1">
            <tr>
                <?php foreach ($columns as $col): ?>
                    <th><?=$col;?></th>
                <?php endforeach; ?>
            </tr>
            <?php while ($row = db_row($rs)): ?>
            <tr ondblclick="mark_row(this)">
                <?php foreach ($row as $k => $v): ?>
                    <?php
                        if (!@$_GET['full_content']) {
                            $v = str_truncate($v, 50);
                        }
                        $v = html_once($v);
                        $nl2br = @$_GET['nl2br'];
                        if (@$_GET['full_content']) {
                            $v = str_wrap($v, 80, '<br>');
                        }
                        if (@$_GET['nl2br']) {
                            $v = nl2br($v);
                        }
                        $v = stripslashes(stripslashes($v));
                        if (@$_GET['search']) {
                            $search = @$_GET['search'];
                            $search_quote = preg_quote($search);
                            $v = preg_replace('#('.$search_quote.')#i', '<span style="background: yellow;">$1</span>', $v);
                        }
                        if ($types[$k] == 'int' && (preg_match('#time#i', $k) || preg_match('#date#i', $k))) {
                            $v = date('Y-m-d H:i', $v);
                        }
                    ?>
                    <td <?=$nl2br?'valign="top"':'';?> nowrap><?=is_null($row[$k])?'-':$v;?></td>
                <?php endforeach; ?>
            </tr>
            <?php endwhile; ?>
            <?php db_free($rs); ?>
            </table>

            <?php if ($pages > 1): ?>
            <p>
                <?php if ($page > 1): ?>
                    <a href="<?=url_offset(($page-1)*$limit-$limit);?>">&lt;&lt; Previous</a> &nbsp;
                <?php endif; ?>
                Page <b><?=$page;?></b> of <b><?=$pages;?></b> &nbsp; 
                <?php if ($pages > $page): ?>
                    <a href="<?=url_offset($page*$limit);?>">Next &gt;&gt;</a>
                <?php endif; ?>
            </p>
            <?php endif; ?>

        <?php endif; ?>

    <?php endif; ?>

</body>
</html>
<?php exit; endif; ?>
<?php if (rget('searchdb')): ?>
<?php

    $tables = list_tables();
    $all_types = array();
    $columns  = array();
    foreach ($tables as $table) {
        $types = table_types2($table);
        $columns[$table] = $types;
        $types = array_values($types);
        $all_types = array_merge($all_types, $types);
    }
    $all_types = array_unique($all_types);

    $get = rget(array(
        'types' => 'arr',
        'search' => 'str',
        'md5' => 'bool'
    ));

    if ($get['search'] && $get['md5']) {
        $get['search'] = md5($get['search']);
    }

?>
    <? layout_start(sprintf('Database: %s &gt; Search', $db_name)); ?>
    <h1><a href="<?=$_SERVER['PHP_SELF'];?>">Database: <?=$db_name;?></a> &gt; Search</h1>
    <? conn_info(); ?>

    <form action="<?=$_SERVER['PHP_SELF'];?>" method="get">
    <input type="hidden" name="searchdb" value="1">
    <table>
    <tr>
        <th>Search:</th>
        <td>
            <input type="text" name="search" value="<?=html_once($get['search']);?>" size="40">
            <? if ($get['search'] && $get['md5']): ?>
                md5(<?=html_once(rget('search'));?>)
            <? endif; ?>
            <input type="checkbox" name="md5" id="md5_label" value="1">
            <label for="md5_label">md5</label>
        </td>
    </tr>
    <tr>
        <th>Columns:</th>
        <td>
            <? foreach ($all_types as $type): ?>
                <input type="checkbox" id="type_<?=$type;?>" name="types[<?=$type;?>]" value="1" <?=checked(isset($get['types'][$type]));?>>
                <label for="type_<?=$type;?>"><?=$type;?></label>
            <? endforeach; ?>
        </td>
    </tr>
    <tr>
        <td colspan="2" class="none">
            <input type="submit" value="Search">
        </td>
    </tr>        
    </table>
    </form>

    <? if ($get['search'] && !count($get['types'])): ?>
        <p>No columns selected.</p>
    <? endif; ?>

    <? if ($get['search'] && count($get['types'])): ?>

        <p>Searching <b><?=count($tables);?></b> tables for: <b><?=html_once($get['search']);?></b></p>

        <? $found_any = false; ?>
        
        <? set_time_limit(0); ?>

        <? foreach ($tables as $table): ?>
            <?

                $where = '';
                $cols2 = array();
                
                $where = '';
                $search = db_escape($get['search']);
                
                foreach ($columns[$table] as $col => $type)
                {
                    if (!in_array($type, array_keys($get['types']))) {
                        continue;
                    }
                    if ($where) {
                        $where .= ' OR ';
                    }
                    if (is_numeric($search)) {
                        $where .= "$col = '$search'";
                    } else {
                        if ('mysql' == $db_driver) {
                            $where .= "$col LIKE '%$search%'";
                        } else if ('pgsql' == $db_driver) {
                            $where .= "$col ILIKE '%$search%'";
                        } else {
                            trigger_error('db_driver not implemented');
                        }
                    }
                }
                
                $found = false;

                if ($where) {
                    $where = 'WHERE '.$where;
                    $found = db_one("SELECT COUNT(*) FROM $table $where");
                }

                if ($found) {
                    $found_any = true;
                }

            ?>

            <?
                if ($where && $found) {
                    $limit = 10;
                    $offset = 0;
                    $pk = table_pk($table);
                    
                    $order = "ORDER BY $pk";
                    $rs = db_query("SELECT * FROM $table $where $order LIMIT $limit OFFSET $offset");
                }
            ?>

            <? if ($where && $found): ?>

                <p>
                    Table: <a href="<?=$_SERVER['PHP_SELF'];?>?viewtable=<?=$table;?>&search=<?=urlencode($get['search']);?>"><b><?=$table;?></b></a><br>
                    Found: <b><?=$found;?></b>
                    <? if ($found > $limit): ?>
                        &nbsp;<a href="<?=$_SERVER['PHP_SELF'];?>?viewtable=<?=$table;?>&search=<?=urlencode($get['search']);?>">show all &gt;&gt;</a>
                    <? endif; ?>
                </p>

                <table cellspacing="1">
                <tr>
                    <?php foreach ($columns[$table] as $col => $type): ?>
                        <th><?=$col;?></th>
                    <?php endforeach; ?>
                </tr>
                <?php while ($row = db_row($rs)): ?>
                <tr>
                    <?php foreach ($row as $k => $v): ?>
                        <?php
                            $v = str_truncate($v, 50);
                            $v = html_once($v);
                            $v = stripslashes(stripslashes($v));
                            $search = $get['search'];
                            $search_quote = preg_quote($search);
                            $v = preg_replace('#('.$search_quote.')#i', '<span style="background: yellow;">$1</span>', $v);
                            if ($columns[$table][$k] == 'int' && (preg_match('#time#i', $k) || preg_match('#date#i', $k))) {
                                $v = date('Y-m-d H:i', $v);
                            }
                        ?>
                        <td nowrap><?=$v;?></td>
                    <?php endforeach; ?>
                </tr>
                <?php endwhile; ?>
                <?php db_free($rs); ?>
                </table>

            <? endif; ?>

        <? endforeach; ?>

        <? if (!$found_any): ?>
            <p>No rows found.</p>
        <? endif; ?>

    <? endif; ?>

    <? layout_end(); ?>
<?php exit; endif; ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=<?=$page_charset;?>">
    <title>Database: <?=$db_name;?></title>
</head>
<body>

<?php layout(); ?>
<h1>Database: <?=$db_name;?></h1>

<?php conn_info(); ?>

<?php $tables = list_tables(); ?>
<?php $status = table_status(); ?>

<p>
    Tables: <b><?=count($tables);?></b>
    &nbsp;-&nbsp;
    Total size: <b><?=size($status['total_size']);?></b>
    &nbsp;-&nbsp;
    <a href="<?=$_SERVER['PHP_SELF'];?>?searchdb=1">Search</a>
    &nbsp;-&nbsp;
    <a href="<?=$_SERVER['PHP_SELF'];?>?import=1">Import</a>
    &nbsp;-&nbsp;
    Export all:
    &nbsp;
    <a href="<?=$_SERVER['PHP_SELF'];?>?dump_all=1">structure</a>
    &nbsp;/&nbsp;
    <a href="<?=$_SERVER['PHP_SELF'];?>?dump_all=2">structure & data</a>
    <? if ('pgsql' == $db_driver): ?>
        &nbsp;
        <small>(Note: pgsql driver does not support export of structure)</small>
    <? endif; ?>
</p>

<table cellspacing="1">
<tr>
    <th>Name</th>
    <th>Count</th>
    <th>Size</th>
    <th>Options</th>
</tr>
<?php foreach ($tables as $table): ?>
<tr>
    <td><a href="<?=$_SERVER['PHP_SELF'];?>?viewtable=<?=$table;?>"><?=$table;?></a></td>
    <?
        if ('mysql' == $db_driver) {
            //$count = db_one("SELECT COUNT(*) FROM $table");
            $count = $status[$table]['count'];
        }
        if ('pgsql' == $db_driver) {
            $count = $status[$table]['count'];
            if (!$count) {
                $count = db_one("SELECT COUNT(*) FROM $table");
            }
        }
    ?>
    <td align="right"><?=$count;?></td>
    <td align="right"><?=size($status[$table]['size']);?></td>
    <td>
        <a href="<?=$_SERVER['PHP_SELF'];?>?dump_table=<?=$table;?>">Export</a>
        &nbsp;-&nbsp;
        <form action="<?=$_SERVER['PHP_SELF'];?>" name="drop_<?=$table;?>" method="post" style="display: inline;"><input type="hidden" name="drop_table" value="<?=$table;?>"></form>
        <a href="javascript:void(0)" onclick="if (confirm('DROP TABLE <?=$table;?> ?')) document.forms['drop_<?=$table;?>'].submit();">Drop</a>
    </td>
</tr>
<?php endforeach; ?>
</table>

</body>
</html>