<?php

/*
	Error logger. Features:
	- display user friendly messages about errors
	- notify via email about error
	- on dev machine display display helpful info for debugging: full backtrace, request data
	(c) Cezary Tomczak [www.gosu.pl]
*/

define('ERROR_LOGGER_DISPLAY', 1);

define('ERROR_LOGGER_FILE', '');
ini_set('error_log', '_php_error_fatal.log');
if (ERROR_LOGGER_FILE && !is_writable('logs')) {
	echo 'error-logger failed: logs directory is not writable';
	exit;
}

// when output buffering cannot be cleaned, RAW msg will be displayed
// define('ERROR_LOGGER_MSG_RAW', 'An unknown error occured. Server administrator has been notified.');
// define('ERROR_LOGGER_MSG', file_get_contents('error-template.html'));
// define('ERROR_LOGGER_EMAIL', 'test@example.com;test2@example.com');
// define('ERROR_LOGGER_EMAIL_CHARSET', 'utf-8');

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors','on');
//ini_set('error_log', '__php_error_fatal.log');

// errors will be displayed on DEV machine
define('ERROR_LOGGER_DEV', ('127.0.0.1' == $_SERVER['REMOTE_ADDR'] || strpos($_SERVER['SERVER_NAME'], '.dev') !== false));

if (ERROR_LOGGER_DEV) {
    ini_set('display_errors', 1);
}

if (!defined('ERROR_LOGGER_FILE')) {
    define('ERROR_LOGGER_FILE', '__php_error.log');
}
if (!defined('ERROR_LOGGER_MSG_RAW')) {
    define('ERROR_LOGGER_MSG_RAW', 'An unknown error occured. Server administrator has been notified.');
}
if (!defined('ERROR_LOGGER_MSG')) {
    define('ERROR_LOGGER_MSG', ERROR_LOGGER_MSG_RAW);
}
if (!defined('ERROR_LOGGER_EMAIL')) {
    define('ERROR_LOGGER_EMAIL', null);
}
if (!defined('ERROR_LOGGER_EMAIL_CHARSET')) {
    define('ERROR_LOGGER_EMAIL_CHARSET', 'utf-8');
}
if (!defined('ERROR_LOGGER_NL')) {
    define('ERROR_LOGGER_NL', "\n");
}
if (!defined('ERROR_LOGGER_DISPLAY')) {
    define('ERROR_LOGGER_DISPLAY', false);
}

set_error_handler('error_logger');

function error_logger($errNo, $errMsg, $file, $line)
{
    if (!($errNo & error_reporting())) { return; }
    while (@ob_end_clean()) {}

    $errType = array (
        1 => "Php Error", 2 => "Php Warning", 4 => "Parsing Error", 8 => "Php Notice",
        16 => "Core Error", 32 => "Core Warning", 64 => "Compile Error", 128 => "Compile Warning",
        256 => "Php User Error", 512 => "Php User Warning", 1024 => "Php User Notice"
    );
    $info = array();
    if (($errNo & E_USER_ERROR) && is_array($arr = @unserialize($errMsg))) {
        foreach ($arr as $k => $v) {
            $info[$k] = $v;
        }
    }
    $trace = array();
    if (function_exists('debug_backtrace')) {
        $trace = debug_backtrace();
        array_shift($trace);
    }
    $err = '';
    $err .= "  ERROR: {$errType[$errNo]}".ERROR_LOGGER_NL;
    $err .= "   FILE: ".basename($file)." [$line] ($file)".ERROR_LOGGER_NL;

    if (!count($info)) {
        $errMsg = wordwrap($errMsg, 60, ERROR_LOGGER_NL.'         ');
        $err .= "MESSAGE: $errMsg".ERROR_LOGGER_NL;
    }
    $ip = $_SERVER['REMOTE_ADDR'];
    $user = @$_COOKIE['user_id'] || @$_COOKIE['id_user'] || @$_COOKIE['userId'];
    if (count($_POST)) {
        $passwords = array('password', 'pass', 'pwd');
        foreach ($passwords as $pass) {
            foreach ($_POST as $k => $v) {
                if (strpos(strtolower($k), $pass) !== false) {
                    $_POST[$k] = '****';
                    $_REQUEST[$k] = '****';
                }
            }
        }
        $post = trim(print_r($_POST, true));
    } else {
        $post = 'empty';
    }

    $err .= "    URL: ".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'].ERROR_LOGGER_NL;
    $err .= sprintf("REQUEST: %s [ip] %s [user] %s [date]", $ip, $user ? $user : 'null', date('Y-m-d H:i:s')).ERROR_LOGGER_NL;
    $err .= "   POST: $post".ERROR_LOGGER_NL;

    foreach ($info as $k => $v) {
        $err .= strtoupper($k).": $v".ERROR_LOGGER_NL;
    }
    if (count($trace)) {
        $err .= "  TRACE: ";
        $trace_1 = true;
        foreach ($trace as $v) {
            if ($trace_1) {
                $trace_1 = false;
            } else {
                $err .= '         ';
            }
            $err .= basename(@$v['file'])." [".@$v['line']."] (".@$v['file'].")".ERROR_LOGGER_NL;
        }
    }
    $err .= ERROR_LOGGER_NL;
    $err .= '--------------------------------------------------------------------------------';
    $err .= ERROR_LOGGER_NL;

    if (ERROR_LOGGER_DEV)
    {
        if (!headers_sent()) {
            while (@ob_end_clean()) {}
        }
        echo '<pre>';
        echo $err;
        echo '</pre>';
        exit;
    }

    if (ERROR_LOGGER_FILE)
    {
        if ($fp = @fopen(ERROR_LOGGER_FILE, 'a')) {
            fwrite($fp, $err);
            fclose($fp);
        } else {
			echo '<div style="color: red;">ERROR LOGGER: fopen(log_file) failed</div>';
		}
    }

    if (ERROR_LOGGER_EMAIL)
    {
        $emails = explode(';', ERROR_LOGGER_EMAIL);
        foreach ($emails as $email)
        {
            $Mail =& new error_logger_Mail();
            $Mail->setFrom($_SERVER['SERVER_NAME']);
            $Mail->setReply('error@'.$_SERVER['SERVER_NAME']);
            $Mail->setTo($email);
            $Mail->setSubj(sprintf('[%s] PHP error', $_SERVER['SERVER_NAME']));
            $Mail->setBody($err);
            if (!$Mail->send()) {
				echo '<div style="color: red;">ERROR LOGGER: mail() failed</div>';
			}
        }
    }

    if (ERROR_LOGGER_DISPLAY)
    {
        if (!headers_sent()) {
            while (@ob_end_clean()) {}
        }
        echo '<pre>';
        echo $err;
        echo '</pre>';
        exit;
    }

    if (!headers_sent()) {
        while (@ob_end_clean()) {}
        header('HTTP/1.0 503 Service Unavailable');
        echo ERROR_LOGGER_MSG;
    } else {
        echo ERROR_LOGGER_MSG_RAW;
    }

    exit;
}

class error_logger_Mail
{
    var $charset = ERROR_LOGGER_EMAIL_CHARSET;
    var $ctencoding = '8bit';
    var $contentType = 'text/plain'; // text/plain or text/html

    var $from;
    var $replyTo;
    var $to;
    var $subject;
    var $body;

    function error_logger_Mail($from = null, $replyTo = null, $to = null, $subject = null, $body = null) {
        $this->from    = $from;
        $this->replyTo = $replyTo;
        $this->to      = $to;
        $this->subject = $subject;
        $this->body    = $body;
    }

    function setCharset($charset)
    {
        $this->charset = $charset;
    }
    function setFrom($from)       { $this->from = $from; }
    function setReply($replyTo) { $this->replyTo = $replyTo; }
    function setTo($to)           { $this->to = $to; }
    function setSubj($subject) { $this->subject = $subject; }
    function setBody($body)       { $this->body = $body; }

    function attachFile() {}

    function send() {

        if (!isset($this->from))    trigger_error('Mail::send() failed, "from" is not set', E_USER_ERROR);
        if (!isset($this->replyTo)) trigger_error('Mail::send() failed, "replyTo" is not set', E_USER_ERROR);
        if (!isset($this->to))      trigger_error('Mail::send() failed, "to" is not set', E_USER_ERROR);
        if (!isset($this->subject)) trigger_error('Mail::send() failed, "subject" is not set', E_USER_ERROR);
        if (!isset($this->body))    trigger_error('Mail::send() failed, "body" is not set', E_USER_ERROR);

        $charset     = $this->charset;
        $ctencoding  = $this->ctencoding;
        $contentType = $this->contentType;

        $from    = $this->quo($this->from);
        $replyTo = $this->replyTo;
        $to      = $this->to;
        $subject = $this->quo($this->subject);
        $body    = $this->body;

        $xMailer = 'PHP/' . phpversion();

        $h  = "From: {$from} <{$replyTo}>".ERROR_LOGGER_NL;
        $h .= "X-Sender: <{$replyTo}>".ERROR_LOGGER_NL;
        $h .= "X-Mailer: {$xMailer}".ERROR_LOGGER_NL;
        $h .= "Return-Path: <{$replyTo}>".ERROR_LOGGER_NL;
        $h .= "Mime-Version: 1.0".ERROR_LOGGER_NL;
        $h .= "Content-Type: {$contentType}; charset={$charset}".ERROR_LOGGER_NL;
        $h .= "Content-Transfer-Encoding: {$ctencoding}";

        return @mail($to, $subject, $body, $h);
    }

    function quo($s) {
        $s = str_replace('%', '=', rawurlencode($s));
        $s = "=?{$this->charset}?Q?{$s}?=";
        return $s;
    }
}

?>